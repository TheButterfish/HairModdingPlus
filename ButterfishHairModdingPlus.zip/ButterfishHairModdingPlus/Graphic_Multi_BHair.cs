﻿using HarmonyLib;
using UnityEngine;
using Verse;

namespace ButterfishHairModdingPlus
{
    class Graphic_Multi_BHair : Graphic_Multi
    {
        private Material[] matsBack = new Material[4];

        public Material BackMatAt(Rot4 rot)
        {
            if (rot.AsInt >= 0 && rot.AsInt <= 3)
            {
                return matsBack[rot.AsInt];
            }
            else
            {
                return BaseContent.BadMat;
            }
        }

        public override void Init(GraphicRequest req)
        {
            //-------------------------REPLICATED VANILLA CODE-------------------------
            data = req.graphicData;
            path = req.path;
            color = req.color;
            colorTwo = req.colorTwo;
            drawSize = req.drawSize;

            //look for front layer textures
            Texture2D[] frontLayerArray = new Texture2D[4];
            frontLayerArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north", reportFailure: false);
            frontLayerArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east", reportFailure: false);
            frontLayerArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south", reportFailure: false);
            frontLayerArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west", reportFailure: false);
            if (frontLayerArray[0] == null)
            {
                if (frontLayerArray[2] != null)
                {
                    frontLayerArray[0] = frontLayerArray[2];
                    //drawRotatedExtraAngleOffset = 180f;
                    Traverse.Create(this).Field("drawRotatedExtraAngleOffset").SetValue(180f);
                }
                else if (frontLayerArray[1] != null)
                {
                    frontLayerArray[0] = frontLayerArray[1];
                    //drawRotatedExtraAngleOffset = -90f;
                    Traverse.Create(this).Field("drawRotatedExtraAngleOffset").SetValue(-90f);
                }
                else if (frontLayerArray[3] != null)
                {
                    frontLayerArray[0] = frontLayerArray[3];
                    //drawRotatedExtraAngleOffset = 90f;
                    Traverse.Create(this).Field("drawRotatedExtraAngleOffset").SetValue(90f);
                }
                else
                {
                    frontLayerArray[0] = ContentFinder<Texture2D>.Get(req.path, reportFailure: false);
                }
            }
            if (frontLayerArray[0] == null)
            {
                Log.Error("Failed to find any textures at " + req.path + " while constructing " + this.ToStringSafe());
                return;
            }
            if (frontLayerArray[2] == null)
            {
                frontLayerArray[2] = frontLayerArray[0];
            }
            if (frontLayerArray[1] == null)
            {
                if (frontLayerArray[3] != null)
                {
                    frontLayerArray[1] = frontLayerArray[3];
                    //eastFlipped = base.DataAllowsFlip;
                    Traverse.Create(this).Field("eastFlipped").SetValue(DataAllowsFlip);
                }
                else
                {
                    frontLayerArray[1] = frontLayerArray[0];
                }
            }
            if (frontLayerArray[3] == null)
            {
                if (frontLayerArray[1] != null)
                {
                    frontLayerArray[3] = frontLayerArray[1];
                    //westFlipped = base.DataAllowsFlip;
                    Traverse.Create(this).Field("westFlipped").SetValue(DataAllowsFlip);
                }
                else
                {
                    frontLayerArray[3] = frontLayerArray[0];
                }
            }

            //look for front layer masks
            Texture2D[] frontLayerMaskArray = new Texture2D[4];
            frontLayerMaskArray[0] = ContentFinder<Texture2D>.Get(req.path + "_northm", reportFailure: false);
            frontLayerMaskArray[1] = ContentFinder<Texture2D>.Get(req.path + "_eastm", reportFailure: false);
            frontLayerMaskArray[2] = ContentFinder<Texture2D>.Get(req.path + "_southm", reportFailure: false);
            frontLayerMaskArray[3] = ContentFinder<Texture2D>.Get(req.path + "_westm", reportFailure: false);

            //-------------------------REPLICATED VANILLA CODE-------------------------

            Traverse.Create(this).Field("mats").SetValue(GetMatsFrom(req, frontLayerArray, frontLayerMaskArray));



            //look for back layer textures
            Texture2D[] backLayerArray = new Texture2D[4];
            backLayerArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_back", reportFailure: false);
            backLayerArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_back", reportFailure: false);
            backLayerArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_back", reportFailure: false);
            backLayerArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_back", reportFailure: false);

            //look for back layer masks
            Texture2D[] backLayerMaskArray = new Texture2D[backLayerArray.Length];
            backLayerMaskArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_backm", reportFailure: false);
            backLayerMaskArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_backm", reportFailure: false);
            backLayerMaskArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_backm", reportFailure: false);
            backLayerMaskArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_backm", reportFailure: false);

            //convert textures into Materials
            matsBack = GetMatsFrom(req, backLayerArray, backLayerMaskArray);
        }

        public static Material[] GetMatsFrom(GraphicRequest req, Texture2D[] inputTextureArray, Texture2D[] inputMaskArray)
        {
            Material[] convertedTex = new Material[inputTextureArray.Length];

            for (int i = 0; i < inputTextureArray.Length; i++)
            {
                if (inputTextureArray[i] != null)
                {
                    Texture2D mask;
                    if (inputMaskArray[i] != null)
                    {
                        mask = inputMaskArray[i];
                    }
                    else
                    {
                        int texWidth = inputTextureArray[i].width;
                        int texHeight = inputTextureArray[i].height;

                        if (texWidth == texHeight)
                        {
                            DefaultMask.CheckMasksReady();

                            switch (texWidth)
                            {
                                case 64:
                                    mask = DefaultMask.defaultMask_64;
                                    break;
                                case 128:
                                    mask = DefaultMask.defaultMask_128;
                                    break;
                                case 256:
                                    mask = DefaultMask.defaultMask_256;
                                    break;
                                case 512:
                                    mask = DefaultMask.defaultMask_512;
                                    break;
                                default:
                                    mask = DefaultMask.CreateDefaultMask(texWidth, texHeight);
                                    break;
                            }
                        }
                        else
                        {
                            mask = DefaultMask.CreateDefaultMask(texWidth, texHeight);
                        }
                    }

                    MaterialRequest tempMatReq = default(MaterialRequest);
                    tempMatReq.mainTex = inputTextureArray[i];
                    tempMatReq.shader = req.shader;
                    tempMatReq.color = req.color;
                    tempMatReq.colorTwo = req.colorTwo;
                    tempMatReq.maskTex = mask;
                    tempMatReq.shaderParameters = req.shaderParameters;

                    //save converted texture
                    convertedTex[i] = MaterialPool.MatFrom(tempMatReq);
                }
            }

            return convertedTex;
        }
    }

    class DefaultMask
    {
        public static Texture2D defaultMask_64, defaultMask_128, defaultMask_256, defaultMask_512;

        DefaultMask()
        {
            SetPresetMasks();
        }

        public static Texture2D CreateDefaultMask(int width, int height)
        {
            Texture2D redMask = new Texture2D(width, height);
            Color fillColor = new Color(1, 0, 0);
            Color[] fillColorArray = redMask.GetPixels();

            for (var i = 0; i < fillColorArray.Length; ++i)
            {
                fillColorArray[i] = fillColor;
            }

            redMask.SetPixels(fillColorArray);

            redMask.Apply();

            return redMask;
        }

        public static void SetPresetMasks()
        {
            defaultMask_64 = CreateDefaultMask(64, 64);
            defaultMask_128 = CreateDefaultMask(128, 128);
            defaultMask_256 = CreateDefaultMask(256, 256);
            defaultMask_512 = CreateDefaultMask(512, 512);
        }

        public static void CheckMasksReady()
        {
            if (defaultMask_64 == null || defaultMask_128 == null || defaultMask_256 == null || defaultMask_512 == null)
            {
                SetPresetMasks();
            }
        }
    }
}
