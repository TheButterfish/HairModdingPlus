﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ButterfishBackHairLayer
{
    [StaticConstructorOnStartup]
    public class Base
    {
        static Base()
        {
            Harmony harmony = new Harmony(id: "butterfish.backhairlayer");
            Harmony.DEBUG = true;

            harmony.Patch(original: AccessTools.Method(type: typeof(Graphic_Multi),
                                                       name: "Init",
                                                       parameters: new Type[] { typeof(GraphicRequest) }),
                          prefix: null,
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                     methodName: "LoadBackHairTextures"));

            harmony.Patch(original: AccessTools.Method(type: typeof(PawnGraphicSet),
                                                       name: "ResolveAllGraphics"),
                          prefix: null,
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                     methodName: "UseCutoutComplex"));

            harmony.Patch(original: AccessTools.Method(type: typeof(PawnRenderer),  
                                                       name: "RenderPawnInternal",
                                                       parameters: new Type[] { typeof(Vector3), typeof(float), typeof(bool), typeof(Rot4), typeof(Rot4), typeof(RotDrawMode), typeof(bool), typeof(bool), typeof(bool) } ), 
                          prefix: null, 
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base), 
                                                     methodName: "DrawBackHairLayer"));

            try
            {
                ((Action)(() =>
                {
                    if (LoadedModManager.RunningModsListForReading.Any(x => x.PackageId == "killface.facialstuff"))
                    {
                        harmony.Patch(original: AccessTools.Method(type: typeof(FacialStuff.Harmony.HarmonyPatch_PawnRenderer),
                                                                   name: "RecalcRootLocY"),
                                                                   //parameters: new Type[] { typeof(Vector3), typeof(Pawn), typeof(FacialStuff.CompBodyAnimator) } ),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                                 methodName: "FSCompat_GetCalcRootLoc"));

                        harmony.Patch(original: AccessTools.Method(type: typeof(FacialStuff.HumanHeadDrawer),
                                                                   name: "DrawHairAndHeadGear",
                                                                   parameters: new Type[] { typeof(Vector3), typeof(Vector3), typeof(RotDrawMode), typeof(Quaternion), typeof(bool), typeof(bool), typeof(Vector3) } ),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                                 methodName: "FSCompat_DrawBackHairLayer"));

                        harmony.Unpatch(original: AccessTools.Method(type: typeof(PawnRenderer),
                                                                     name: "RenderPawnInternal",
                                                                     parameters: new Type[] { typeof(Vector3), typeof(float), typeof(bool), typeof(Rot4), typeof(Rot4), typeof(RotDrawMode), typeof(bool), typeof(bool), typeof(bool) }),
                                        type: HarmonyPatchType.Postfix,
                                        harmonyID: "butterfish.backhairlayer");
                    }
                }))();
            }
            catch (TypeLoadException) { }
        }

        public static void LoadBackHairTextures(Graphic_Multi __instance, ref GraphicRequest req)
        {
            //get original `mats` private variable
            Material[] matsOri = Traverse.Create(__instance).Field("mats").GetValue<Material[]>();

            //prepare replacement variable for `mats` to hold additional textures
            Material[] matsPlus = new Material[8];

            //copy over regular textures i.e. front textures from original
            matsOri.CopyTo(matsPlus, 0);

            //look for back layer textures
            Texture2D[] backLayerArray = new Texture2D[4];
            backLayerArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_back", reportFailure: false);
            backLayerArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_back", reportFailure: false);
            backLayerArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_back", reportFailure: false);
            backLayerArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_back", reportFailure: false);

            //look for back layer masks
            Texture2D[] backLayerMaskArray = new Texture2D[backLayerArray.Length];
            if (req.shader.SupportsMaskTex())
            {
                backLayerMaskArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_backm", reportFailure: false);
                backLayerMaskArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_backm", reportFailure: false);
                backLayerMaskArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_backm", reportFailure: false);
                backLayerMaskArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_backm", reportFailure: false);
            }

            //convert textures into Materials
            for (int i = 0; i < backLayerArray.Length; i++)
            {
                if (backLayerArray[i] != null)
                {
                    MaterialRequest req2 = default(MaterialRequest);
                    req2.mainTex = backLayerArray[i];
                    req2.shader = req.shader;
                    req2.color = req.color;
                    req2.colorTwo = req.colorTwo;
                    req2.maskTex = backLayerMaskArray[i];
                    req2.shaderParameters = req.shaderParameters;

                    //save converted texture into extended array
                    matsPlus[i + 4] = MaterialPool.MatFrom(req2);
                }
            }

            //replace original `mats` variable with extended array containing back layer textures
            Traverse.Create(__instance).Field("mats").SetValue(matsPlus);
        }

        public static void UseCutoutComplex(PawnGraphicSet __instance)
        {
            /*
            if (__instance.pawn.RaceProps.Humanlike)
            {
                __instance.hairGraphic = GraphicDatabase.Get<Graphic_Multi>(__instance.pawn.story.hairDef.texPath, ShaderDatabase.CutoutComplex, Vector2.one, __instance.pawn.story.hairColor);
                return;
            }
            */
        }

        public static void DrawBackHairLayer(PawnRenderer __instance,
                                             ref Vector3 rootLoc, 
                                             ref float angle, 
                                             ref Rot4 headFacing, 
                                             ref RotDrawMode bodyDrawType, 
                                             ref bool portrait, 
                                             ref bool headStump)
        {
            PawnGraphicSet graphics = __instance.graphics;

            if (!graphics.AllResolved)
            {
                graphics.ResolveAllGraphics();
            }
            if (graphics.headGraphic != null)
            {

                //-------------------------REPLICATED VANILLA CODE-------------------------
                Quaternion quaternion = Quaternion.AngleAxis(angle, new Vector3(0f, 1f, 0f));
                Vector3 b = quaternion * __instance.BaseHeadOffsetAt(headFacing);
                Vector3 loc2 = rootLoc + b;
                //-------------------------REPLICATED VANILLA CODE-------------------------


                loc2.y -= 0.0303030312f;    //changed from original, used to be +=


                bool flag = false;
                if (!portrait || !Prefs.HatsOnlyOnMap)
                {

                    //-------------------------REPLICATED VANILLA CODE-------------------------
                    List<ApparelGraphicRecord> apparelGraphics = graphics.apparelGraphics;
                    for (int j = 0; j < apparelGraphics.Count; j++)
                    {
                        if (apparelGraphics[j].sourceApparel.def.apparel.LastLayer == ApparelLayerDefOf.Overhead)
                        {
                            if (!apparelGraphics[j].sourceApparel.def.apparel.hatRenderedFrontOfFace)
                            {
                                flag = true;
                            }
                        }
                    }
                    //-------------------------REPLICATED VANILLA CODE-------------------------

                }
                if (!flag && bodyDrawType != RotDrawMode.Dessicated && !headStump)
                {
                    Material[] matsPlus = Traverse.Create(graphics.hairGraphic).Field("mats").GetValue<Material[]>();

                    if (matsPlus.Length > 4)
                    {
                        Material baseMat = matsPlus[headFacing.AsInt + 4];

                        if (baseMat != null)
                        {
                            if (graphics.pawn.IsInvisible())
                            {
                                baseMat = InvisibilityMatPool.GetInvisibleMat(baseMat);
                            }
                            Material resultMat = graphics.flasher.GetDamagedMat(baseMat);

                            GenDraw.DrawMeshNowOrLater(graphics.HairMeshSet.MeshAt(headFacing), mat: resultMat, loc: loc2, quat: quaternion, drawNow: portrait);
                        }
                    }
                }
            }
        }

        public static void FSCompat_GetCalcRootLoc(ref Vector3 rootLoc, out Vector3 __state)
        {
            __state = rootLoc;
        }

        public static void FSCompat_DrawBackHairLayer(FacialStuff.HumanHeadDrawer __instance,
                                                      ref Vector3 __state,
                                                      ref Vector3 hairLoc,
                                                      ref RotDrawMode bodyDrawType,
                                                      ref Quaternion headQuat,
                                                      ref bool renderBody,
                                                      ref bool portrait)
        {
            //-------------------------REPLICATED FACIAL STUFF CODE-------------------------
            Mesh hairMesh = __instance.GetPawnHairMesh(portrait);
            PawnGraphicSet curGraphics = Traverse.Create(__instance).Field("Graphics").GetValue<PawnGraphicSet>();
            List<ApparelGraphicRecord> apparelGraphics = curGraphics.apparelGraphics;
            List<ApparelGraphicRecord> headgearGraphics = null;
            if (!apparelGraphics.NullOrEmpty())
            {
                headgearGraphics = apparelGraphics
                                  .Where(x => x.sourceApparel.def.apparel.LastLayer == ApparelLayerDefOf.Overhead ||
                                              x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("OnHead") ||
                                              x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("StrappedHead") ||
                                              x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("MiddleHead")).ToList();
            }

            FacialStuff.CompBodyAnimator animator = __instance.CompAnimator;

            bool noRenderGoggles = FacialStuff.Controller.settings.FilterHats;

            bool showRoyalHeadgear = __instance.Pawn.royalty?.MostSeniorTitle != null && FacialStuff.Controller.settings.ShowRoyalHeadgear;
            bool noRenderRoofed = animator != null && animator.HideHat && !showRoyalHeadgear;
            bool noRenderBed = FacialStuff.Controller.settings.HideHatInBed && !renderBody && !showRoyalHeadgear;
            //-------------------------REPLICATED FACIAL STUFF CODE-------------------------



            Material[] matsPlus = Traverse.Create(curGraphics.hairGraphic).Field("mats").GetValue<Material[]>();
            Rot4 curHeadFacing = Traverse.Create(__instance).Field("HeadFacing").GetValue<Rot4>();
            hairLoc.y = __state.y - 0.0303030312f;



            if (!headgearGraphics.NullOrEmpty())
            {
                //-------------------------REPLICATED FACIAL STUFF CODE-------------------------
                bool filterHeadgear = portrait && Prefs.HatsOnlyOnMap || !portrait && noRenderRoofed;

                // Draw regular hair if appparel or environment allows it (FS feature)
                if (bodyDrawType != RotDrawMode.Dessicated)
                {
                    // draw full or partial hair
                    bool apCoversFullHead =
                    headgearGraphics.Any(
                                         x => x.sourceApparel.def.apparel.bodyPartGroups.Contains(BodyPartGroupDefOf
                                                                                                 .FullHead)
                                           && !x.sourceApparel.def.apparel.hatRenderedFrontOfFace);

                    bool apCoversUpperHead =
                    headgearGraphics.Any(
                                         x => x.sourceApparel.def.apparel.bodyPartGroups.Contains(BodyPartGroupDefOf
                                                                                                 .UpperHead)
                                           && !x.sourceApparel.def.apparel.hatRenderedFrontOfFace);
                    //-------------------------REPLICATED FACIAL STUFF CODE-------------------------

                    if (__instance.CompFace.Props.hasOrganicHair || noRenderBed || filterHeadgear
                     || (!apCoversFullHead && !apCoversUpperHead && noRenderGoggles))
                    {
                        if (matsPlus.Length > 4)
                        {
                            Material mat = matsPlus[curHeadFacing.AsInt + 4];
                            GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, mat, portrait);
                        }
                    }
                    /*
                    else if (FacialStuff.Controller.settings.MergeHair) // && !apCoversFullHead)
                    {
                        // If not, display the hair cut
                        FacialStuff.HairCut.HairCutPawn hairPawn = FacialStuff.HairCut.CutHairDB.GetHairCache(__instance.Pawn);
                        Material hairCutMat = hairPawn.HairCutMatAt(curHeadFacing);
                        if (hairCutMat != null)
                        {
                            GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, hairCutMat, portrait);
                        }
                    }
                    */
                }
            }
            else
            {
                // Draw regular hair if no hat worn
                if (bodyDrawType != RotDrawMode.Dessicated)
                {
                    if (matsPlus.Length > 4)
                    {
                        Material hairMat = matsPlus[curHeadFacing.AsInt + 4];
                        GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, hairMat, portrait);
                    }
                }
            }
        }
    }
}
