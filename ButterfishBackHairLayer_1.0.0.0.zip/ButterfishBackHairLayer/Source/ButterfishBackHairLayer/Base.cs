﻿using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ButterfishBackHairLayer
{
    [StaticConstructorOnStartup]
    public class Base
    {
        private static Rot4 newHeadFacing;

        static Base()
        {
            Harmony harmony = new Harmony(id: "rimworld.butterfish.backhairlayer");
            //Harmony.DEBUG = true;

            newHeadFacing = Rot4.Invalid;

            harmony.Patch(original: AccessTools.Method(type: typeof(Graphic_Multi),
                                                       name: "Init",
                                                       parameters: new Type[] { typeof(GraphicRequest) }),
                          prefix: null,
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                     methodName: "LoadBackHairTextures"));

            harmony.Patch(original: AccessTools.Method(type: typeof(PawnRenderer),  
                                                       name: "RenderPawnInternal",
                                                       parameters: new Type[] { typeof(Vector3), typeof(float), typeof(bool), typeof(Rot4), typeof(Rot4), typeof(RotDrawMode), typeof(bool), typeof(bool), typeof(bool) }), 
                          prefix: null, 
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base), 
                                                     methodName: "DrawBackHairLayer"));

            try
            {
                ((Action)(() =>
                {
                    if (LoadedModManager.RunningModsListForReading.Any(x => x.Name == "Facial Stuff 1.1"))
                    {
                        harmony.Patch(original: AccessTools.Method(type: typeof(FacialStuff.PawnHeadDrawer),
                                                                   name: "GetPawnHairMesh"),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishBackHairLayer.Base),
                                                                 methodName: "FSCompat_UpdateLatestHeadRotation"));
                    }
                }))();
            }
            catch (TypeLoadException) { }
        }

        public static void LoadBackHairTextures(Graphic_Multi __instance, ref GraphicRequest req)
        {
            //get original `mats` private variable
            Material[] matsOri = Traverse.Create(__instance).Field("mats").GetValue<Material[]>();

            //prepare replacement variable for `mats` to hold additional textures
            Material[] matsPlus = new Material[8];

            //copy over regular textures i.e. front textures from original
            matsOri.CopyTo(matsPlus, 0);

            //look for back layer textures
            Texture2D[] backLayerArray = new Texture2D[4];
            backLayerArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_back", reportFailure: false);
            backLayerArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_back", reportFailure: false);
            backLayerArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_back", reportFailure: false);
            backLayerArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_back", reportFailure: false);

            //look for back layer masks
            Texture2D[] backLayerMaskArray = new Texture2D[backLayerArray.Length];
            if (req.shader.SupportsMaskTex())
            {
                backLayerMaskArray[0] = ContentFinder<Texture2D>.Get(req.path + "_north_backm", reportFailure: false);
                backLayerMaskArray[1] = ContentFinder<Texture2D>.Get(req.path + "_east_backm", reportFailure: false);
                backLayerMaskArray[2] = ContentFinder<Texture2D>.Get(req.path + "_south_backm", reportFailure: false);
                backLayerMaskArray[3] = ContentFinder<Texture2D>.Get(req.path + "_west_backm", reportFailure: false);
            }

            //convert textures into Materials
            for (int i = 0; i < backLayerArray.Length; i++)
            {
                if (backLayerArray[i] != null)
                {
                    MaterialRequest req2 = default(MaterialRequest);
                    req2.mainTex = backLayerArray[i];
                    req2.shader = req.shader;
                    req2.color = req.color;
                    req2.colorTwo = req.colorTwo;
                    req2.maskTex = backLayerMaskArray[i];
                    req2.shaderParameters = req.shaderParameters;

                    //save converted texture into extended array
                    matsPlus[i + 4] = MaterialPool.MatFrom(req2);
                }
            }

            //replace original `mats` variable with extended array containing back layer textures
            Traverse.Create(__instance).Field("mats").SetValue(matsPlus);
        }

        public static void DrawBackHairLayer(PawnRenderer __instance, ref Vector3 rootLoc, ref float angle, ref Rot4 bodyFacing, ref Rot4 headFacing, ref RotDrawMode bodyDrawType, ref bool portrait, ref bool headStump)
        {
            if (newHeadFacing != Rot4.Invalid)
            {
                headFacing = newHeadFacing;
                newHeadFacing = Rot4.Invalid;
            }

            PawnGraphicSet graphics = __instance.graphics;

            if (!graphics.AllResolved)
            {
                graphics.ResolveAllGraphics();
            }
            if (graphics.headGraphic != null)
            {

                //-------------------------REPLICATED VANILLA CODE-------------------------
                Quaternion quaternion = Quaternion.AngleAxis(angle, new Vector3(0f, 1f, 0f));
                Vector3 vector = rootLoc;
                Vector3 a = rootLoc;
                if (bodyFacing != new Rot4(0))
                {
                    a.y += 7f / 264f;
                    vector.y += 0.0227272734f;
                }
                else
                {
                    a.y += 0.0227272734f;
                    vector.y += 7f / 264f;
                }
                Vector3 b = quaternion * __instance.BaseHeadOffsetAt(headFacing);
                Vector3 loc2 = rootLoc + b;
                //-------------------------REPLICATED VANILLA CODE-------------------------


                loc2.y -= 0.0303030312f;    //changed from original, used to be +=


                bool flag = false;
                if (!portrait || !Prefs.HatsOnlyOnMap)
                {

                    //-------------------------REPLICATED VANILLA CODE-------------------------
                    List<ApparelGraphicRecord> apparelGraphics = graphics.apparelGraphics;
                    for (int j = 0; j < apparelGraphics.Count; j++)
                    {
                        if (apparelGraphics[j].sourceApparel.def.apparel.LastLayer == ApparelLayerDefOf.Overhead)
                        {
                            if (!apparelGraphics[j].sourceApparel.def.apparel.hatRenderedFrontOfFace)
                            {
                                flag = true;
                            }
                        }
                    }
                    //-------------------------REPLICATED VANILLA CODE-------------------------

                }
                if (!flag && bodyDrawType != RotDrawMode.Dessicated && !headStump)
                {
                    Material[] matsPlus = Traverse.Create(graphics.hairGraphic).Field("mats").GetValue<Material[]>();

                    if (matsPlus.Length > 4)
                    {
                        Material baseMat = matsPlus[headFacing.AsInt + 4];

                        if (baseMat != null)
                        {
                            if (graphics.pawn.IsInvisible())
                            {
                                baseMat = InvisibilityMatPool.GetInvisibleMat(baseMat);
                            }
                            Material resultMat = graphics.flasher.GetDamagedMat(baseMat);

                            GenDraw.DrawMeshNowOrLater(graphics.HairMeshSet.MeshAt(headFacing), mat: resultMat, loc: loc2, quat: quaternion, drawNow: portrait);
                        }
                    }
                }
            }
        }

        public static void FSCompat_UpdateLatestHeadRotation(FacialStuff.PawnHeadDrawer __instance)
        {
            newHeadFacing = Traverse.Create(__instance).Field("HeadFacing").GetValue<Rot4>();
        }
    }
}
