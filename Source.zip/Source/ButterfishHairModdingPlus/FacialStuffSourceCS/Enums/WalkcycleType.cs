﻿namespace FacialStuff
{
    public enum WalkCycleType
    {
        None,
        Biped, 
        Quadruped,
        Centipede,
    }
}