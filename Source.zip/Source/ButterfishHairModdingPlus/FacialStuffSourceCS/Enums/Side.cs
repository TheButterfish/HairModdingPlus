﻿namespace FacialStuff
{
    #region Public Enums

    public enum Side
    {
        Left = 0,

        Right = 1
    }

    #endregion Public Enums
}