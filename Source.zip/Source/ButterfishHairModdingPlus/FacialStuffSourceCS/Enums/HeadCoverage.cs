﻿namespace FacialStuff
{
    public enum HeadCoverage : byte
    {
        None = 0,
        UpperHead = 1,
        FullHead = 2
    }
}