﻿namespace FacialStuff
{
    public enum BeardType : byte
    {
        LowerBeard = 0,

        FullBeard = 1,

        None = 2
    }
}