﻿namespace FacialStuff
{
    public enum HeadType : byte
    {
        Normal = 0,

        Pointy = 1,

        Wide = 2,

        Undefined = 3
    }
}