﻿namespace FacialStuff
{
    public enum KeyStatus
    {
        Automatic = 0,
        Manual = 1
    }
}