namespace FacialStuff
{
    public enum PartStatus
    {
        Natural = 0, Missing = 1, Artificial = 2, DisplayOverBeard=3
    }
}