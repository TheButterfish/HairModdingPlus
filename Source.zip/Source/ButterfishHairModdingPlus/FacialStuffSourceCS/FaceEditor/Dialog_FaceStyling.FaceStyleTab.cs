﻿namespace FacialStuff.FaceEditor
{
    public partial class Dialog_FaceStyling
    {

        #region Public Enums

        public enum FaceStyleTab : byte
        {
            Hair,

            Beard,

            Eye,

            Brow,

            TypeSelector
        }

        #endregion Public Enums

    }

}