namespace FacialStuff.FaceEditor.UI.Util
{
    public delegate void SelectionChangeListener(object sender);
}