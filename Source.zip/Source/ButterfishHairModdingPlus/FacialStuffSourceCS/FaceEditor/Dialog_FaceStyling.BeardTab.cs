﻿namespace FacialStuff.FaceEditor
{
    public partial class Dialog_FaceStyling
    {
        #region Public Enums

        #endregion Public Enums

        #region Private Enums

        private enum BeardTab : byte
        {
            Combinable,

            FullBeards
        }

        #endregion Private Methods

}
}