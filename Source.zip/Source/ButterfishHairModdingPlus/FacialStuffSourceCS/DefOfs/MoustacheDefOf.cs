﻿using FacialStuff.Defs;
using RimWorld;

namespace FacialStuff.DefOfs
{
    [DefOf]
    public static class MoustacheDefOf
    {
        public static MoustacheDef Shaved;
    }
}