﻿using Verse;

namespace FacialStuff.Components
{
    public class CompSkeleton : ThingComp
    {

    }
}
