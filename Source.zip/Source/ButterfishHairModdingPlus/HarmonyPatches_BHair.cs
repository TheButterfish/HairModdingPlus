﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace ButterfishHairModdingPlus
{
    [StaticConstructorOnStartup]
    public class HarmonyPatches_BHair
    {
        public static bool loadedGradientHair;
        private static float tempBaseDrawLocY;
        private static IEnumerable<object> PC_hairOptions;

        static HarmonyPatches_BHair()
        {
            Harmony harmony = new Harmony(id: "butterfish.hairmoddingplus");
            Harmony.DEBUG = true;

            loadedGradientHair = false;
            tempBaseDrawLocY = 0;

            /*
            foreach (ModContentPack mod in LoadedModManager.RunningModsListForReading)
            {
                Log.Message("Butterfish: Loaded mod " + mod.PackageId);
            }
            */

            harmony.Patch(original: AccessTools.Method(type: typeof(PawnGraphicSet),
                                                       name: "ResolveAllGraphics"),
                          prefix: null,
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                     methodName: "UseModifiedGraphicParams"));

            MethodBase m_RenderPawnInternal = AccessTools.Method(type: typeof(PawnRenderer),
                                                                                   name: "RenderPawnInternal",
                                                                                   parameters: new Type[] { typeof(Vector3), typeof(float), typeof(bool), typeof(Rot4), typeof(Rot4), typeof(RotDrawMode), typeof(bool), typeof(bool), typeof(bool) } );

            harmony.Patch(original: m_RenderPawnInternal, 
                          prefix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                    methodName: "RecalcRootLocY"), 
                          postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair), 
                                                     methodName: "DrawBackHairLayer"));

            try
            {
                ((Action)(() =>
                {
                    if (LoadedModManager.RunningModsListForReading.Any(x => x.PackageId == "edb.preparecarefully"))
                    {
                        harmony.Patch(original: AccessTools.Method(type: typeof(EdB.PrepareCarefully.ProviderPawnLayers),
                                                                   name: "InitializeDefaultPawnLayers"),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "PCCompat_AddHairColor2Layer"));

                        harmony.Patch(original: AccessTools.Method(type: typeof(EdB.PrepareCarefully.ProviderPawnLayers),
                                                                   name: "InitializeHairOptions"),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "PCCompat_GetHairOptions"));

                        harmony.Patch(original: AccessTools.Method(type: typeof(EdB.PrepareCarefully.PawnLayerHair),
                                                                   name: "GetSelectedColor"),
                                      prefix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "PCCompat_GetSelectedColor"),
                                      postfix: null);

                        harmony.Patch(original: AccessTools.Method(type: typeof(EdB.PrepareCarefully.PawnLayerHair),
                                                                   name: "SelectColor"),
                                      prefix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "PCCompat_SelectColor"),
                                      postfix: null);
                    }
                }))();
            }
            catch (TypeLoadException) { }

            try
            {
                ((Action)(() =>
                {
                    if (LoadedModManager.RunningModsListForReading.Any(x => x.PackageId == "killface.facialstuff"))
                    {
                        harmony.Patch(original: AccessTools.Method(type: typeof(FacialStuff.CompBodyAnimator),
                                                                   name: "DrawBody"),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "FSCompat_GetBaseDrawLocY"));

                        harmony.Patch(original: AccessTools.Method(type: typeof(FacialStuff.HumanHeadDrawer),
                                                                   name: "DrawHairAndHeadGear",
                                                                   parameters: new Type[] { typeof(Vector3), typeof(Vector3), typeof(RotDrawMode), typeof(Quaternion), typeof(bool), typeof(bool), typeof(Vector3) } ),
                                      prefix: null,
                                      postfix: new HarmonyMethod(methodType: typeof(ButterfishHairModdingPlus.HarmonyPatches_BHair),
                                                                 methodName: "FSCompat_DrawBackHairLayer"));

                        harmony.Unpatch(original: m_RenderPawnInternal,
                                        type: HarmonyPatchType.Prefix,
                                        harmonyID: "butterfish.hairmoddingplus");

                        harmony.Unpatch(original: m_RenderPawnInternal,
                                        type: HarmonyPatchType.Postfix,
                                        harmonyID: "butterfish.hairmoddingplus");
                    }
                }))();
            }
            catch (TypeLoadException) { }

            if (LoadedModManager.RunningModsListForReading.Any(x => x.PackageId == "automatic.gradienthair"))
            {
                loadedGradientHair = true;
            }
        }

        public static void UseModifiedGraphicParams(PawnGraphicSet __instance)
        {
            if (__instance.pawn.RaceProps.Humanlike)
            {
                string hairTexturePath = __instance.pawn.story.hairDef.texPath;

                HairColor2_Comp comp = __instance.pawn.GetComp<HairColor2_Comp>();
                Color hairColor2 = Color.white;
                if (comp != null)
                {
                    hairColor2 = comp.HairColorTwoExpo.hairColor2;
                }

                if (loadedGradientHair)
                {
                    Color gradientColor = Compat_GradientHair.GHCompat_TryGetGradientColor(__instance.pawn);
                    hairTexturePath += ":" + gradientColor.a.ToString() + ":" + gradientColor.r.ToString() + ":" + gradientColor.g.ToString() + ":" + gradientColor.b.ToString();
                    hairTexturePath += Compat_GradientHair.GHCompat_TryGetGradientPath(__instance.pawn);
                }

                __instance.hairGraphic = GraphicDatabase.Get<Graphic_Multi_BHair>(hairTexturePath, ShaderDatabase.CutoutComplex, Vector2.one, __instance.pawn.story.hairColor, hairColor2);
            }
        }

        //credits to Killface for this snippet of code
        public static void RecalcRootLocY(PawnRenderer __instance, ref Vector3 rootLoc, bool portrait)
        {
            Pawn pawn = __instance.graphics.pawn;

            if (!portrait && pawn.Spawned)
            {
                Vector3 loc = rootLoc;
                CellRect viewRect = Find.CameraDriver.CurrentViewRect;
                viewRect = viewRect.ExpandedBy(1);

                List<Pawn> pawns = new List<Pawn>();
                foreach (Pawn otherPawn in pawn.Map.mapPawns.AllPawnsSpawned)
                {
                    if (!viewRect.Contains(otherPawn.Position)) { continue; }
                    if (otherPawn == pawn) { continue; }
                    if (otherPawn.DrawPos.x < loc.x - 0.5f) { continue; }
                    if (otherPawn.DrawPos.x > loc.x + 0.5f) { continue; }
                    if (otherPawn.DrawPos.z >= loc.z) { continue; }

                    pawns.Add(otherPawn);
                }

                if (!pawns.NullOrEmpty())
                {
                    float pawnOffset = 0.05f * pawns.Count;
                    loc.y -= pawnOffset;
                }

                rootLoc = loc;
            }
        }

        public static void DrawBackHairLayer(PawnRenderer __instance,
                                             ref Vector3 rootLoc, 
                                             ref float angle, 
                                             ref Rot4 headFacing, 
                                             ref RotDrawMode bodyDrawType, 
                                             ref bool portrait, 
                                             ref bool headStump)
        {
            PawnGraphicSet graphics = __instance.graphics;
            if (!graphics.AllResolved)
            {
                graphics.ResolveAllGraphics();
            }
            Graphic_Multi_BHair hairGraphicExtended = (Graphic_Multi_BHair) graphics.hairGraphic;

            //if has head and hair graphics
            if (graphics.headGraphic != null && hairGraphicExtended != null)
            {
                Material hairMat = hairGraphicExtended.BackMatAt(headFacing);

                if (hairMat != null)
                {
                    //-------------------------REPLICATED VANILLA CODE-------------------------
                    Quaternion quaternion = Quaternion.AngleAxis(angle, new Vector3(0f, 1f, 0f));
                    Vector3 b = quaternion * __instance.BaseHeadOffsetAt(headFacing);
                    Vector3 loc2 = rootLoc + b;
                    //-------------------------REPLICATED VANILLA CODE-------------------------


                    //loc2.y -= 0.0303030312f;    //changed from original, used to be +=


                    bool flag = false;
                    if (!portrait || !Prefs.HatsOnlyOnMap)
                    {

                        //-------------------------REPLICATED VANILLA CODE-------------------------
                        List<ApparelGraphicRecord> apparelGraphics = graphics.apparelGraphics;
                        for (int j = 0; j < apparelGraphics.Count; j++)
                        {
                            if (apparelGraphics[j].sourceApparel.def.apparel.LastLayer == ApparelLayerDefOf.Overhead)
                            {
                                if (!apparelGraphics[j].sourceApparel.def.apparel.hatRenderedFrontOfFace)
                                {
                                    flag = true;
                                }
                            }
                        }
                        //-------------------------REPLICATED VANILLA CODE-------------------------

                    }
                    if (!flag && bodyDrawType != RotDrawMode.Dessicated && !headStump)
                    {
                        if (graphics.pawn.IsInvisible())
                        {
                            hairMat = InvisibilityMatPool.GetInvisibleMat(hairMat);
                        }
                        Material resultMat = graphics.flasher.GetDamagedMat(hairMat);

                        GenDraw.DrawMeshNowOrLater(graphics.HairMeshSet.MeshAt(headFacing), mat: resultMat, loc: loc2, quat: quaternion, drawNow: portrait);
                    }
                }
            }
        }

        public static void PCCompat_AddHairColor2Layer(ref List<EdB.PrepareCarefully.PawnLayer> __result)
        {
            Type t_PawnLayer = GenTypes.GetTypeInAnyAssembly("EdB.PrepareCarefully.PawnLayer");
            try
            {
                if (t_PawnLayer != null)
                {
                    EdB.PrepareCarefully.PawnLayer hairColor2Layer = new EdB.PrepareCarefully.PawnLayerHair() { Name = "Hair Color 2", Label = ("HairModdingPlus.PCPatch.HairColorTwo").Translate() };
                    hairColor2Layer.Options = (List<EdB.PrepareCarefully.PawnLayerOption>) PC_hairOptions;
                    PC_hairOptions = null;
                    __result.Insert(1, hairColor2Layer);
                }
            }
            catch (TypeLoadException) { }
        }

        public static void PCCompat_GetHairOptions(ref List<EdB.PrepareCarefully.PawnLayerOption> __result)
        {
            PC_hairOptions = __result;
        }

        public static bool PCCompat_GetSelectedColor(EdB.PrepareCarefully.PawnLayerHair __instance, ref EdB.PrepareCarefully.CustomPawn pawn, ref Color __result)
        {
            Type t_CustomPawn = GenTypes.GetTypeInAnyAssembly("EdB.PrepareCarefully.CustomPawn");
            try
            {
                if (t_CustomPawn != null)
                {
                    if (__instance.Name == "Hair Color 2")
                    {
                        __result = HairColor2_API.GetHairColor2(pawn.Pawn);

                        return false;
                    }
                }
            }
            catch (TypeLoadException) { }

            return true;
        }

        public static bool PCCompat_SelectColor(EdB.PrepareCarefully.PawnLayerHair __instance, ref EdB.PrepareCarefully.CustomPawn pawn, Color color)
        {
            Type t_CustomPawn = GenTypes.GetTypeInAnyAssembly("EdB.PrepareCarefully.CustomPawn");
            try
            {
                if (t_CustomPawn != null)
                {
                    if (__instance.Name == "Hair Color 2")
                    {
                        HairColor2_API.SetHairColor2(pawn.Pawn, color);
                        pawn.MarkPortraitAsDirty();

                        return false;
                    }
                }
            }
            catch (TypeLoadException) { }

            return true;
        }

        public static void FSCompat_GetBaseDrawLocY(ref Vector3 rootLoc)
        {
            tempBaseDrawLocY = rootLoc.y;
        }

        public static void FSCompat_DrawBackHairLayer(FacialStuff.HumanHeadDrawer __instance,
                                                      ref Vector3 hairLoc,
                                                      ref RotDrawMode bodyDrawType,
                                                      ref Quaternion headQuat,
                                                      ref bool renderBody,
                                                      ref bool portrait)
        {
            //-------------------------REPLICATED FACIAL STUFF CODE-------------------------
            PawnGraphicSet curGraphics = Traverse.Create(__instance).Field("Graphics").GetValue<PawnGraphicSet>();
            if (!curGraphics.AllResolved)
            {
                curGraphics.ResolveAllGraphics();
            }

            Graphic_Multi_BHair hairGraphicExtended = (Graphic_Multi_BHair) curGraphics.hairGraphic;
            if (hairGraphicExtended != null)
            {
                Mesh hairMesh = __instance.GetPawnHairMesh(portrait);
                Rot4 curHeadFacing = Traverse.Create(__instance).Field("HeadFacing").GetValue<Rot4>();
                Material hairMat = hairGraphicExtended.BackMatAt(curHeadFacing);

                if (hairMat != null)
                {
                    List<ApparelGraphicRecord> apparelGraphics = curGraphics.apparelGraphics;
                    List<ApparelGraphicRecord> headgearGraphics = null;
                    if (!apparelGraphics.NullOrEmpty())
                    {
                        headgearGraphics = apparelGraphics
                                          .Where(x => x.sourceApparel.def.apparel.LastLayer == ApparelLayerDefOf.Overhead ||
                                                      x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("OnHead") ||
                                                      x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("StrappedHead") ||
                                                      x.sourceApparel.def.apparel.LastLayer == DefDatabase<ApparelLayerDef>.GetNamedSilentFail("MiddleHead")).ToList();
                    }

                    FacialStuff.CompBodyAnimator animator = __instance.CompAnimator;

                    bool noRenderGoggles = FacialStuff.Controller.settings.FilterHats;

                    bool showRoyalHeadgear = __instance.Pawn.royalty?.MostSeniorTitle != null && FacialStuff.Controller.settings.ShowRoyalHeadgear;
                    bool noRenderRoofed = animator != null && animator.HideHat && !showRoyalHeadgear;
                    bool noRenderBed = FacialStuff.Controller.settings.HideHatInBed && !renderBody && !showRoyalHeadgear;
                    //-------------------------REPLICATED FACIAL STUFF CODE-------------------------



                    hairLoc.y = tempBaseDrawLocY;
                    tempBaseDrawLocY = 0;



                    if (!headgearGraphics.NullOrEmpty())
                    {
                        //-------------------------REPLICATED FACIAL STUFF CODE-------------------------
                        bool filterHeadgear = portrait && Prefs.HatsOnlyOnMap || !portrait && noRenderRoofed;

                        // Draw regular hair if appparel or environment allows it (FS feature)
                        if (bodyDrawType != RotDrawMode.Dessicated)
                        {
                            // draw full or partial hair
                            bool apCoversFullHead =
                            headgearGraphics.Any(
                                                 x => x.sourceApparel.def.apparel.bodyPartGroups.Contains(BodyPartGroupDefOf
                                                                                                         .FullHead)
                                                   && !x.sourceApparel.def.apparel.hatRenderedFrontOfFace);

                            bool apCoversUpperHead =
                            headgearGraphics.Any(
                                                 x => x.sourceApparel.def.apparel.bodyPartGroups.Contains(BodyPartGroupDefOf
                                                                                                         .UpperHead)
                                                   && !x.sourceApparel.def.apparel.hatRenderedFrontOfFace);
                            //-------------------------REPLICATED FACIAL STUFF CODE-------------------------

                            if (__instance.CompFace.Props.hasOrganicHair || noRenderBed || filterHeadgear
                             || (!apCoversFullHead && !apCoversUpperHead && noRenderGoggles))
                            {
                                GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, hairMat, portrait);
                            }
                            /*
                            else if (FacialStuff.Controller.settings.MergeHair) // && !apCoversFullHead)
                            {
                                // If not, display the hair cut
                                FacialStuff.HairCut.HairCutPawn hairPawn = FacialStuff.HairCut.CutHairDB.GetHairCache(__instance.Pawn);
                                Material hairCutMat = hairPawn.HairCutMatAt(curHeadFacing);
                                if (hairCutMat != null)
                                {
                                    GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, hairCutMat, portrait);
                                }
                            }
                            */
                        }
                    }
                    else
                    {
                        // Draw regular hair if no hat worn
                        if (bodyDrawType != RotDrawMode.Dessicated)
                        {
                            GenDraw.DrawMeshNowOrLater(hairMesh, hairLoc, headQuat, hairMat, portrait);
                        }
                    }
                }
            }
        }
    }
}
