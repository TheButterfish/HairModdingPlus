﻿namespace FacialStuff
{
    public enum TweenThing
    {
        HandLeft = 0,
        HandRight = 1,
        FootLeft = 2,
        FootRight = 3,
        Equipment = 4,
        Max = 5
    }
}