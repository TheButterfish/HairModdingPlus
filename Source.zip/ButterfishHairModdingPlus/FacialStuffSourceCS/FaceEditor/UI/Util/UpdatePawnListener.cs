namespace FacialStuff.FaceEditor.UI.Util
{
    public delegate void UpdatePawnListener(object sender, object value, object value2);
}