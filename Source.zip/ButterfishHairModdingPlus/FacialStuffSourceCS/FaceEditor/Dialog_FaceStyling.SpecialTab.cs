﻿#if legacy
namespace FacialStuff.FaceEditor
{
    public partial class Dialog_FaceStyling
    {
        #region Private Enums

        public enum SpecialTab : byte
        {
            Head,

            Body,

            Any
        }

        #endregion Private Methods

    }
}
#endif