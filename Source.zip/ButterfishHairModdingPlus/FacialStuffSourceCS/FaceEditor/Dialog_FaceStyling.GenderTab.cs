﻿namespace FacialStuff.FaceEditor
{
    public partial class Dialog_FaceStyling
    {
        public enum GenderTab : byte
        {
            Female,

            Male,

            Any,

            All
        }

        // private void CheckSelectedFacePresetHasName()
        // }
        // }
        // SelectedFacePreset.label = "Unnamed";
        // {
        // if (SelectedFacePreset != null && SelectedFacePreset.label.NullOrEmpty())

        // {
    }

    // public struct Baldness
    // {
    // public int currentBaldness;
    // public int maxBaldness;
    // }
}